<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>แจ้งข้อมูลการชำระเงิน</title>
    <link rel="icon" href="iconlogo.png" sizes="32x32">



    <link rel="stylesheet" href="node_modules/bootstrap/dist/css/bootstrap.min.css">


    
</head>
<body style = ' background-image: url("images/m.jpeg"); '>

    <?php
        require_once('connect.php'); // ดึงไฟล์เชื่อมต่อ Database เข้ามาใช้งาน
        /**
         * ตรวจสอบเงื่อนไขที่ว่า ตัวแปร $_POST['submit'] ได้ถูกกำหนดขึ้นมาหรือไม่
         */
        if(isset($_POST['submit'])){
            /**
             * ตั้งชื่อไฟล์ภาพใหม่
             */
            $temp = explode('.',$_FILES['fileUpload']['name']);
            $new_name = round(microtime(true)) . '.' . end($temp);
            /**
             * ตรวจสอบเงื่อนไขที่ว่า สามารถย้ายไฟล์รูปภาพเข้าสู่ storage ของเราได้หรือไม่
             */
            if(move_uploaded_file($_FILES['fileUpload']['tmp_name'], 'uploads/' .$new_name)){
                /**
                 * สร้างตัวแปร $sql เพื่อเก็บคำสั่ง Sql
                 * จากนั้นให้ใช้คำสั่ง $conn->query($sql) เพื่อที่จะประมาณผลการทำงานของคำสั่ง sql
                 */
                $sql = "INSERT INTO `payment` (`pay_ID`, `order_ID`, `pay_date`, `total_price`, `bank_name`, `telephone`, `pay_time`,`picture`) 
                        VALUES (NULL, 2, '".$_POST['pay_date']."', '".$_POST['total_price']."', '".$_POST['bank_name']."', '".$_POST['telephone']."', '".$_POST['pay_time']."', '". $new_name."');";
                $result = $conn->query($sql);
                /**
                 * ตรวจสอบเงื่อนไขที่ว่าการประมวณผลคำสั่งนี่สำเร็จหรือไม่
                 */                
                if($result){
                    echo '<script> alert("แจ้งชำระการโอนเงิน สำเร็จ!")</script>';
                    header('Refresh:0; url=index.php');
                }else{
                    echo '<script> alert("ไม่สำเร็จ !")</script>';
                }
            }
        }
    ?>

    <div class="container">
        <div class="row">
            <div class="col-md-8 mx-auto mt-5">
                <div class="card">
                    <form action="" method="POST" enctype="multipart/form-data">           
                        <div class="card-header text-center">
                        <h2>ข้อมูลการโอน
                        </div>
                        <div class="card-body">
                            
                            <div class="form-group row">
                                <label for="username" class="col-sm-3 col-form-label">ชำระเงินวันที่ :</label>
                                <div class="col-sm-9">
                                    <input type="date" class="form-control" id="pay_date" name="pay_date" required>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="password" class="col-sm-3 col-form-label">จำนวนที่โอน :</label>
                                <div class="col-sm-9">
                                    <input type="number" class="form-control" id="total_price" name="total_price" required>
                                </div>    
                            </div>
                            <div class="form-group row">
                                <label for="first_name" class="col-sm-3 col-form-label">เลือกธนาคาร :</label>
                                <div class="col-sm-9">
                                <select class="form-control" id="bank_name" name="bank_name" require>
                                <option>ธนาคารกรุงไทย</option>
                                <option>ธนาคารกสิกรไทย</option>
                                <option>ธนาคารกรุงศรี</option>
                                <option>ธนาคารทหารไทย</option>
                                <option>ธนาคารออมสิน</option>
                                <option>ธนาคารกรงเทพ</option>
                            </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="last_name" class="col-sm-3 col-form-label">เบอร์โทรศัพท์ :</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" id="telephone" name="telephone" required>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="email" class="col-sm-3 col-form-label">เวลาที่ชำระ :</label>
                                <div class="col-sm-9">
                                    <input type="time" class="form-control" id="pay_time" name="pay_time" required>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="fileUpload" class="col-sm-3 col-form-label">อัพโหลดสลิปการโอนเงิน ที่นี่ !</label>
                                <div class="col-sm-9">
                                    <input type="file" class="form-control" id="fileUpload" name="fileUpload" onchange="readURL(this)">
                                </div>    
                            </div>
                            <figure class="figure text-center d-none">
                                <img id="imgUpload" class="figure-img img-fluid rounded" alt="">
                            </figure>
                        </div>
                        <div class="card-footer text-center">
                            <input type="submit" name="submit" class="btn btn-success" value="แจ้งชำระการโอนเงิน">
                            <a class="btn btn-primary" href="index.php">ย้อนกลับไป</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- ติดตั้งการใช้งาน Javascript ต่างๆ -->       
    <script src="node_modules/jquery/dist/jquery.min.js"></script>
    <script src="node_modules/popper.js/dist/umd/popper.min.js"></script>
    <script src="node_modules/bootstrap/dist/js/bootstrap.min.js"></script>

    <script>
        /**
         * ประกาศ function readURL()
         * เพื่อทำการตรวจสอบว่า มีไฟล์ภาพที่กำหนดถูกอัพโหลดหรือไม่
         * ถ้ามีไฟล์ภาพที่กำหนดถูกอัพโหลดอยู่ ให้แสดงไฟล์ภาพนั้นผ่าน elements ที่มี id="imgUpload"
         */
        function readURL(input){
            if(input.files[0]){
                var reader = new FileReader();
                $('.figure').addClass('d-block');
                reader.onload = function (e) {
                    console.log(e.target.result)
                    $('#imgUpload').attr('src',e.target.result).width(240);
                }  
                reader.readAsDataURL(input.files[0]);
            }         
        }
    </script>
</body>
</html>