
<div class="shopping-cart-table">
        <div class="carttitle">
            <div class="cart-info title">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ชื่อสินค้า</div>
            <div class="cart-info">จำนวน</div>
            <div class="cart-info price">ราคา(บาท)</div>
        </div>
<?php
            foreach ($cartItem as $item) {
                ?>
		<div class="cart-item-container">
            <div class="cart-info title">
                <img class="cart-image"
                    src="<?php echo $item["image"]; ?>">
                    <?php echo $item["name"]; ?>
                </div>

            <div class="cart-info">
                        <?php echo $item["quantity"]; ?>
                    </div>

            <div class="cart-info price">
                        <?php echo $item["price"]; ?>
                    </div>


            <div class="cart-info action">
                <a
                    href="index.php?action=remove&id=<?php echo $item["cart_id"]; ?>"
                    class="btnRemoveAction"><img
                    src="image/icon-delete.png" alt="icon-delete"
                    title="Remove Item" /></a>
            </div>
        </div>
				<?php
            }
            ?>
</div>
