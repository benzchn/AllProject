<?php
session_start();
?>
<?php
require_once "ShoppingCart.php";


if(!empty($_SESSION['user_ID'])){
    $member_id = $_SESSION['user_ID']; // you can your integerate authentication module here to get logged in member
        }else{
            $member_id = 0;
        }

$shoppingCart = new ShoppingCart();
?>
<HTML>
<HEAD>
<TITLE>หน้ายืนยันการชำระเงิน</TITLE>
<link rel="icon" href="iconlogo.png" sizes="32x32">
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="style.css" type="text/css" rel="stylesheet" />
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
</HEAD>
<BODY style = ' background-image: url("images/m.jpeg"); ' >
<?php
$cartItem = $shoppingCart->getMemberCartItem($member_id);
$item_quantity = 0;
$item_price = 0;
if (! empty($cartItem)) {
    if (! empty($cartItem)) {

        foreach ($cartItem as $item) {
            $item_quantity = $item_quantity + $item["quantity"];
            $item_price = $item_price + ($item["price"] * $item["quantity"]);
        }
    }
}
?>
<div id="shopping-cart">
        <div class="txt-heading">
            <div class="txt-heading-label">ตะกร้าสินค้า</div>

            <a id="btnEmpty" href="index.php?action=empty"><img
                src="image/empty-cart.png" alt="empty-cart"
                title="Empty Cart" class="float-right" /></a>
            <div class="cart-status">
                <div>จำนวนสินค้า : <?php echo $item_quantity; ?> ชิ้น</div>
                <div>ราคารวม : <?php echo $item_price; ?> บาท</div>
            </div>
        </div>
        <?php
        if (! empty($cartItem)) {
            ?>
<?php
            require_once ("cart-list.php");
            ?>
<?php
        } // End if !empty $cartItem
        ?>
</div>


<?php if(! empty($_SESSION['user_ID'])){
    ?>
   <form name="frm_customer_detail" action="process-order.php" method="POST">
   <div class="frm-heading">
       <div class="txt-heading-label"><h3>ข้อมูลลูกค้า</div>
   </div>
   <div class="frm-customer-detail">
       <div class="form-row">
           <div class="input-field">
               ชื่อ - นามสกุล :<input type="text" name="name" id="name" value= "<?php echo $_SESSION['user_fname'];?> <?php echo $_SESSION['user_lname'];?>" require>
           </div>
<br>
           <div class="input-field">
               ที่อยู่ : <input type="text" name="address" value="<?php echo $_SESSION['user_add'];?>" require>
           </div>
<br>
           <div class="input-field">
              เบอร์โทรศัพท์ : <input type="text" name="phone" value="<?php echo $_SESSION['user_tel'];?>" require>
           </div>
       </div>

   </div>
   <div style="display: flex;
justify-content: center;
align-items: center;">
       <input type="submit" class="btn-action"
               name="proceed_payment" value="ยืนยันการจ่ายเงิน"/>
               &nbsp; <a class="btn-action" href="index.php">หน้าหลัก</a>
   </div>
   </form>

<?php }else{ ?>
   <form name="frm_customer_detail" action="process-order.php" method="POST">
   <div class="frm-heading">
       <div class="txt-heading-label">ข้อมูลลูกค้า</div>
   </div>
   <div class="frm-customer-detail">
       <div class="form-row">
           <div class="input-field">
               <input type="text" name="name" id="name"
                   PlaceHolder="ชื่อลูกค้า" required>
           </div>
<br>
           <div class="input-field">
               <input type="text" name="address" PlaceHolder="ที่อยู่" required>
           </div>
<br>
           <div class="input-field">
               <input type="text" name="phone" PlaceHolder="เบอร์โทร" required>
           </div>
       </div>

   </div>
   <div style="display: flex;
justify-content: center;
align-items: center;">
       <input type="submit" class="btn-action"
               name="proceed_payment" value="ยืนยันการจ่ายเงิน"/>
               &nbsp; <a class="btn-action" href="index.php">หน้าหลัก</a>
   </div>
   </form>
   <?php } ?>
    
</BODY>
</HTML>