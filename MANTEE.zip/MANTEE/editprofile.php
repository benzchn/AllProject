<?php session_start();?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>แก้ไขข้อมูลส่วนตัว</title>
    <link rel="icon" href="https://www.img.in.th/images/23a06c25be0feea9fdeb2301bb894e74.png" sizes="32x32">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <link rel="stylesheet" type="text/css" href="styles/main_styles.css">
<!--===============================================================================================-->
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
</head>

<body class="etc">

<!------------------- PHP --------------------------->

<?php require_once('connect.php'); // ดึงไฟล์เชื่อมต่อ Database เข้ามาใช้งาน
                $user_id = $_SESSION['user_ID'];

                $sql = "SELECT * FROM `userdetail` WHERE `user_id` = '".$user_id."'";
                $result1 = $conn->query($sql);

                $row1 = $result1->fetch_assoc();

                $username = $row1['username'];
                $password = $row1['password'];
                $user_fname = $row1['user_fname'];
                $user_lname = $row1['user_lname'];
                $user_email = $row1['user_email'];
                $user_tel = $row1['user_tel'];
                $user_add = $row1['user_add'];

                if(isset($_POST['submit'])) { 

                  $user_fname = $conn->real_escape_string($_POST['user_fname']);
                  $user_lname = $conn->real_escape_string($_POST['user_lname']);
                  $user_add = $conn->real_escape_string($_POST['user_add']);
                  $user_email = $conn->real_escape_string($_POST['user_email']);
                  $user_tel = $conn->real_escape_string($_POST['user_tel']);

                  $sql = "UPDATE `userdetail` SET `user_fname` = '".$user_fname."' ,
                                                  `user_lname` = '".$user_lname."' ,
                                                  `user_add`   = '".$user_add."' ,
                                                  `user_email` = '".$user_email."' ,
                                                  `user_tel`   = '".$user_tel."'
                                              WHERE `user_id` = '".$user_id."';";

                  $result = $conn->query($sql);
                  
                  if($result){
                   
                  echo '<script> alert("อัพเดทข้อมูลเรียบร้อยแล้ว")</script>';
                          header('Refresh:0; location:editprofile.php');
                  }else{
                    echo '<script> alert("อัพเดทข้อมูล ล้มเหลว !")</script>';
                        } 
                }


    ?>
    
<!------------------- PHP --------------------------->

<div class="container" style="padding-top: 60px;">
  <h1 class="page-header">แก้ไขข้อมูล</h1>
  <div class="row">
    <!-- left column -->
    <div class="col-md-4 col-sm-6 col-xs-12">
      <!-- <div class="text-center">
        <img src="" class="avatar img-circle img-thumbnail" alt="">
        <h6>Upload a different photo...</h6>
        <input type="file" class="text-center center-block well well-sm">
      </div> -->
    </div>
    <!-- edit form column -->
    <div class="col-md-8 col-sm-6 col-xs-12 personal-info">
      <!-- <div class="alert alert-info alert-dismissable">
        <a class="panel-close close" data-dismiss="alert">×</a> 
        <i class="fa fa-coffee"></i>
        This is an <strong>.alert</strong>. Use this to show important messages to the user.
      </div> -->
      <h3>ข้อมูลสมาชิก</h3>
      <form class="form-horizontal" role="form" method="post">
        <div class="form-group">
          <label class="col-lg-3 control-label">ชื่อ :</label>
          <div class="col-lg-8">
            <input class="form-control" id="user_fname" name="user_fname" value="<?php echo "$user_fname"?>" type="text">
          </div>
        </div>
        <div class="form-group">
          <label class="col-lg-3 control-label">นามสกุล :</label>
          <div class="col-lg-8">
            <input class="form-control" id="user_lname" name="user_lname" value="<?php echo "$user_lname"?>" type="text">
          </div>
        </div>
        
        <div class="form-group">
          <label class="col-lg-3 control-label">ที่อยู่จัดส่ง :</label>
          <div class="col-lg-8">
            <input class="form-control" id="user_add" name="user_add" value="<?php echo "$user_add"?>" type="text">
          </div>
        </div>

        <div class="form-group">
          <label class="col-lg-3 control-label">เบอร์โทรศัพท์ :</label>
          <div class="col-lg-8">
            <input class="form-control" id="user_tel" name="user_tel" value="<?php echo "$user_tel"?>" type="text">
          </div>
        </div>

        <div class="form-group">
          <label class="col-lg-3 control-label">Email :</label>
          <div class="col-lg-8">
            <input class="form-control" id="user_email" name="user_email" value="<?php echo "$user_email"?>" type="text">
          </div>
        </div>
        
        <!-- <div class="form-group">
          <label class="col-md-3 control-label">ชื่อผู้ใช้งาน :</label>
          <div class="col-md-8">
            <input class="form-control" id="username" name="username" value="<?php echo "$username"?>" type="text">
          </div>
        </div> -->

        <!-- <div class="form-group">
          <label class="col-md-3 control-label">รหัสผ่าน :</label>
          <div class="col-md-8">
            <input class="form-control" id="password" name="password" value="<?php echo "$password"?>" type="password">
          </div>
        </div> -->

        <div class="form-group">
          <label class="col-md-3 control-label"></label>
          <div class="col-md-8">
            <input class="btn btn-primary" type="submit" name="submit" value="บันทึกแก้ไข" type="button">
            <span></span>
            <a class="btn btn-primary" href="index.php">ย้อนกลับ</a>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>
</body>
</html>