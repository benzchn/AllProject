
<div class="row products_row">
	<!-- Product -->
    <?php
    $query = "SELECT * FROM tbl_product WHERE type = '3'";
    $product_array = $shoppingCart->getbag($query);

    if (! empty($product_array)) {
        foreach ($product_array as $key => $value) { ?>

        <div class="col-xl-4 col-md-6">
	    <div class="product">
        <form method="post" action="index.php?action=add&productlist=bag&code=<?php echo $product_array[$key]["code"]; ?>">
        <div class="product_image">
							<img src="<?php echo $product_array[$key]["image"]; ?>" alt=""></div>
                            <div class="product_content">
								<div class="product_info d-flex flex-row align-items-start justify-content-start">
									
										<div>
                                        <div class="product_name"><a href="#"> <?php echo $product_array[$key]["name"] ?> </a></div>
											<div class="product_category"> <?php echo $product_array[$key]["details"] ?></a></div>
										</div>
									
                                    <div class="ml-auto text-right">
										<div class="rating_r rating_r_4 home_item_rating"><i></i><i></i><i></i><i></i><i></i></div>
										<div class="product_price text-right"><span> <?php echo $product_array[$key]["price"] ?> บาท</span></div>
									</div>
								</div>
                                <div class="product_buttons">
									
									<div class="text-right d-flex flex-row align-items-start justify-content-start">
										<div class="product_button product_fav text-center d-flex flex-column align-items-center justify-content-center">
                                            จำนวน <input type="text" class="product-quantity" name="quantity" value="1" size="2" />
										</div>
										<div class="product_button product_cart text-center d-flex flex-column align-items-center justify-content-center">
											<div><div><input type="image" alt="Add-to-cart" style="width: 100%;" src="images/cart.svg" class="svg" /><div>+</div></div></div>
									</div>
									</div>

								</div>
                               
							</div>
							</form>
						</div>
				
					</div>
					
						<?php }
							}
					?>
				</div>
				