<?php session_start();?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>ลงทะเบียนสำหรับลูกค้า</title>
		<link rel="icon" href="..\iconlogo.png" sizes="32x32">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		
		<!-- MATERIAL DESIGN ICONIC FONT -->
		<link rel="stylesheet" href="fonts/material-design-iconic-font/css/material-design-iconic-font.min.css">

		<!-- STYLE CSS -->
		<link rel="stylesheet" href="css/style.css">
	</head>


	<body>
	<?php
        require_once('..\connect.php'); // ดึงไฟล์เชื่อมต่อ Database เข้ามาใช้งาน
        /**
         * ตรวจสอบเงื่อนไขที่ว่า ตัวแปร $_POST['submit'] ได้ถูกกำหนดขึ้นมาหรือไม่
         */
        if(isset($_POST['submit'])){
           
                $sql = "INSERT INTO `userdetail` (`user_fname`, `user_lname`, `user_add`, `user_email`, `user_tel`, `username`, `password`) 
                        VALUES ('".$_POST['user_fname']."', '".$_POST['user_lname']."', '".$_POST['user_add']."', '".$_POST['user_email']."', '".$_POST['user_tel']."', '".$_POST['username']."', '".$_POST['password']."');";
				$result = $conn->query($sql);

				
				$sql1 = "SELECT * FROM `userdetail` WHERE `username` = '".$_POST['username']."' AND `password` = '".$_POST['password']."'";
            $result1 = $conn->query($sql1);
                /**
                 * ตรวจสอบเงื่อนไขที่ว่าการประมวณผลคำสั่งนี่สำเร็จหรือไม่
                 */                
                if($result){
					$row = $result1->fetch_assoc();
					$_SESSION['user_ID'] = $row['user_ID'];
					$_SESSION['username'] = $row['username'];
					$_SESSION['password'] = $row['password'];
					$_SESSION['user_fname'] = $row['user_fname'];
					$_SESSION['user_lname'] = $row['user_lname'];
					$_SESSION['user_tel'] = $row['user_tel'];
					$_SESSION['user_add'] = $row['user_add'];
					$_SESSION['user_email'] = $row['user_email'];
                    echo '<script> alert("สมัครสมาชิกสำเร็จ")</script>';
                    header('Refresh:0; url=..\index.php');
                }else{
                    echo 'no';
                }
            }
        
    ?>

		<div class="wrapper" style="background-image: url('images/bg-registration-form-1.jpg');">
			<div class="inner">
				<div class="image-holder">
					<img src="images/registration-form-1.jpg" alt="">
				</div>
				<form method="post">
					<h3>ลงทะเบียนสำหรับลูกค้า</h3>
					<div class="form-group">
						<input type="text" id="user_fname" name="user_fname" placeholder="ชื่อ" class="form-control" required>
						<input type="text" id="user_lname" name="user_lname" placeholder="นามสกุล" class="form-control" required>
					</div>
					<div class="form-wrapper">
						<input type="text" id="username" name="username" placeholder="ชื่อผู้ใช้" class="form-control" required>
						<i class="zmdi zmdi-account"></i>
					</div>
					<div class="form-wrapper">
						<input type="password" id="password" name="password" placeholder="รหัสผ่านผู้ใช้งาน" class="form-control" required>
						<i class="zmdi zmdi-lock"></i>
					</div>
					<div class="form-wrapper">
						<input type="text" id="user_email" name="user_email" placeholder="Email Address" class="form-control" required>
						<i class="zmdi zmdi-email"></i>
					</div>
					<!-- <div class="form-wrapper">
						<select name="" id="" class="form-control">
							<option value="" disabled selected>Gender</option>
							<option value="male">Male</option>
							<option value="femal">Female</option>
							<option value="other">Other</option>
						</select>
						<i class="zmdi zmdi-caret-down" style="font-size: 17px"></i>
					</div> -->
					<div class="form-wrapper">
						<textarea rows="5" cols="42" id="user_add" name="user_add" placeholder="ที่อยู่" required ></textarea>
						<i class="zmdi zmdi-home"></i>
					</div>
					<div class="form-wrapper">
						<input type="text" id="user_tel" name="user_tel" placeholder="เบอร์โทรศัพท์" class="form-control" required>
						<i class="zmdi zmdi-phone"></i>
					</div>
					<button type="submit" name="submit" > ยืนยัน
						<i class="zmdi zmdi-arrow-right"></i>
					</button>
					
				</form>
			</div>
		</div>
		
	</body><!-- This templates was made by Colorlib (https://colorlib.com) -->
</html>