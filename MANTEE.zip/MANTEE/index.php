<?php
    /**
     * เปิดใช้งาน Session
     */
	session_start();
	
	require_once "ShoppingCart.php";

	if(!empty($_SESSION['user_ID'])){
$member_id = $_SESSION['user_ID']; // you can your integerate authentication module here to get logged in member
	}else{
		$member_id = 0;
	}
$shoppingCart = new ShoppingCart();
if (! empty($_GET["action"])) {
    switch ($_GET["action"]) {
        case "add":
            if (! empty($_POST["quantity"])) {
                
                $productResult = $shoppingCart->getProductByCode($_GET["code"]);
                
                $cartResult = $shoppingCart->getCartItemByProduct($productResult[0]["id"], $member_id);
                
                if (! empty($cartResult)) {
                    // Update cart item quantity in database
                    $newQuantity = $cartResult[0]["quantity"] + $_POST["quantity"];
                    $shoppingCart->updateCartQuantity($newQuantity, $cartResult[0]["id"]);
                } else {
                    // Add to cart table
                    $shoppingCart->addToCart($productResult[0]["id"], $_POST["quantity"], $member_id);
                }
            }
            break;
        case "remove":
            // Delete single entry from the cart
            $shoppingCart->deleteCartItem($_GET["id"]);
            break;
        case "empty":
            // Empty cart
            $shoppingCart->emptyCart($member_id);
            break;
    }
}
?>

<!DOCTYPE html>
<html lang="th-TH">
<head>
<title>MAN - TEE TRENDY STORE | Online Shopping - Manteetrendy.com</title>
    <link rel="icon" href="iconlogo.png" sizes="32x32">
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="Little Closet template">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="styles/bootstrap-4.1.2/bootstrap.min.css">
<link href="plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/animate.css">
<link rel="stylesheet" type="text/css" href="styles/main_styles.css">
<link rel="stylesheet" type="text/css" href="styles/responsive.css">
<link rel="stylesheet" href="node_modules/bootstrap/dist/css/bootstrap.min.css">
    <!-- <link type="text/css" rel="stylesheet" href="CSS/style.css" /> -->
	<!-- <link href="style1.css" type="text/css" rel="stylesheet" > -->
	<link href="style.css" type="text/css" rel="stylesheet" >
</head>
<body>

<?php
$cartItem = $shoppingCart->getMemberCartItem($member_id);
$item_quantity = 0;
$item_price = 0;
if (! empty($cartItem)) {
    if (! empty($cartItem)) {
        foreach ($cartItem as $item) {
            $item_quantity = $item_quantity + $item["quantity"];
            $item_price = $item_price + ($item["price"] * $item["quantity"]);
        }
    }
}
?>

<div class="super_container">

	<!-- Header -->

	<header class="header">
		<div class="header_overlay"></div>
		<div class="header_content d-flex flex-row align-items-center justify-content-start">
			<div class="logo">
				<a href="index.php">
					<div class="d-flex flex-row align-items-center justify-content-start">
						<div style="margin-top : 55px;"><img src="https://sandbox-uploads.imgix.net/u/1555951649-a3e0cbb661cef6b4df22dd53bdba677c?w=150" alt=""></div>
						<div style="margin-top : 55px;"><h1>MAN - TEE TRENDY STORE</div>
					</div>
				</a>	
			</div>
			
			<div class="header_right d-flex flex-row align-items-center justify-content-start ml-auto">
				
				
			<div style="text-align: right;
				margin-right : 20px ;" ><a href="checkstatus.php"><div><img style="width : 200px;" src="images/Tracking.png" alt="ตรวจสอบสถานะ"></div></a></div>
				<div style="text-align: right;
				margin-right : 20px ;" ><a href="payment.php"><div><img style="width : 200px;" src="images/2.png" alt="แจ้งการชำระเงิน"></div></a></div>
				
				<div class="header_phone d-flex flex-row align-items-center justify-content-start">
					<div><div><img src="images/phone.svg" alt="https://www.flaticon.com/authors/freepik"></div></div>
					<div>ติดต่อเรา. <br> 088-0579462</div>
				</div>
			</div>
		</div>

		
		<div class="container" style="
		width: auto;
	height: auto;
	margin: auto;
	float: right;">
		<div>
        <ul >
                   
		<?php if ( isset($_SESSION['user_fname']) ){ ?>
			<li class="nav-item dropdown">
				<br>
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
		  ยินดีต้อนรับ คุณ <?php echo $_SESSION['user_fname']; ?> 
		  </a>
                        
                        <div  class="dropdown-menu"  aria-labelledby="navbarDropdown">
						<a class="dropdown-item" href="editprofile.php">แก้ไขข้อมูล</a>
						<a class="dropdown-item" href="payment.php">แจ้งการโอนเงิน</a>
						<div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="logout.php">ออกจากระบบ</a>
                        </div>
                    </li>
		 
		 <?php } else { ?>
			<li class="nav-item">
				<br>
                        <a class="btn btn-primary" href="Login\login.php">เข้าสู่ระบบ</a>
                        <a class="btn btn-warning" href="Register\register.php">สมัครสมาชิก</a>
						</li>
					<?php } ?>
				</ul>
		</div>
		</div>
		</header>

		<!-- Products -->

			<br><br><br>
		<div class="products">
			<div class="container">
				
				<div class="row page_nav_row">
					<div class="col">
						<div class="page_nav">
						<!-- <div><h7><b style="color: #d0011b;">จัดส่งฟรี</b> บางพื้นที่
                                                        <span style="position: relative;top: -1px">&nbsp;|&nbsp;</span>
                                                        ลด <b style="color: #d0011b;">5%</b>  สำหรับผู้ใช้ที่ลงทะเบียนใหม่
		 </div><br> -->
							<!-- <ul class="d-flex flex-row align-items-start justify-content-center"> -->
								<div style="display: flex; justify-content: center; align-items: center;"><form method="post">
								<h3><a href="index.php?productlist=shirt">👚 เสื้อ</a></li>
								|
								<a href="index.php?productlist=hat">👒 หมวก</a></li>
								|
								<a href="index.php?productlist=bag">👜 กะเป๋า</a></li>
								</form>
								</div>
							<!-- </ul> -->

						</div>
					</div>
				</div>


				<div id="shopping-cart">
        <div class="txt-heading">
            <div class="txt-heading-label">ตะกร้าสินค้า</div>

            <a id="btnEmpty" href="index.php?action=empty"><img
                src="image/empty-cart.png" alt="empty-cart"
                title="Empty Cart" class="float-right" /></a>
            <div class="cart-status">
                <div>จำนวนสินค้า : <?php echo $item_quantity; ?> ชิ้น</div>
                <div>ราคารวม : <?php echo $item_price; ?> บาท</div>
            </div>
        </div>
         <?php
        if (! empty($cartItem)) {
            ?>
<?php
            require_once ("cart-list.php");
            ?>  
            <div class="align-right">
            <a href="process-checkout.php"><button class="btn-action" name="check_out">จ่ายเงิน</button></a>
            </div>
<?php
        } 
        ?>
</div>
				<?php
				
				if (! empty($_GET["productlist"])) {
					switch ($_GET["productlist"]) {
						
						case "shirt" : 	require_once "product-list-shirt.php";
										break;
						case "hat" : 	require_once "product-list-hat.php";
										break;
						case "bag" : 	require_once "product-list-bag.php";
										break;
					}
				}else{
					require_once "product-list-shirt.php";
				}
			
			
?>

			</div>
		</div>


		<!-- Features -->

		<div class="features">
			<div class="container">
				<div class="row">
					
					
					<div class="col-lg-4 feature_col">
						<div class="feature d-flex flex-row align-items-start justify-content-start">
							<div class="feature_left">
								<div class="feature_icon"><img src="images/icon_1.svg" alt=""></div>
							</div>
							<div class="feature_right d-flex flex-column align-items-start justify-content-center">
								<div class="feature_title">จ่ายเงินอย่างปลอดภัย</div>
							</div>
						</div>
					</div>

					
					<div class="col-lg-4 feature_col">
						<div class="feature d-flex flex-row align-items-start justify-content-start">
							<div class="feature_left">
								<div class="feature_icon ml-auto mr-auto"><img src="images/icon_2.svg" alt=""></div>
							</div>
							<div class="feature_right d-flex flex-column align-items-start justify-content-center">
								<div class="feature_title">สินค้ามีคุณภาพ</div>
							</div>
						</div>
					</div>

					
					<div class="col-lg-4 feature_col">
						<div class="feature d-flex flex-row align-items-start justify-content-start">
							<div class="feature_left">
								<div class="feature_icon"><img src="images/icon_3.svg" alt=""></div>
							</div>
							<div class="feature_right d-flex flex-column align-items-start justify-content-center">
								<div class="feature_title">จัดส่งฟรีบางพื้นที่</div>
							</div>
						</div>
					</div>

				</div>
			</div>
		</div>

		<!-- Footer -->

		<footer class="footer">
			<!-- <div class="footer_content"> -->
				<div class="container">
					<div class="row">
						
						
						<div class="col-lg-4 footer_col">
						
								<div class="footer_logo">
									<br><br>
									<a href="index.php">
										<div class="d-flex flex-row align-items-center justify-content-start">
											<div><img src="https://sandbox-uploads.imgix.net/u/1555951649-a3e0cbb661cef6b4df22dd53bdba677c?w=100" alt=""></div>
											<div>MAN - TEE <br> TRENDY STORE</div>
										</div>
									</a>	
								</div>
								
						
						</div>

						<div class="col-lg-4 footer_col">
							<!-- <div class="footer_contact"> -->
								
								<div class="footer_social">
									<div class="footer_title">ลิ้งที่เกี่ยวข้อง</div>
									<ul class="footer_social_list d-flex flex-row align-items-start justify-content-start">
										<li><a href="https://www.facebook.com/thong888999/"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
										<li><a href="https://www.instagram.com/thong9_store/"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
									</ul>
								</div>
							<!-- </div> -->
						</div>
					</div>
				</div>
		
		</footer>
	
		
</div>

<script src="js/jquery-3.2.1.min.js"></script>
<script src="styles/bootstrap-4.1.2/popper.js"></script>
<script src="styles/bootstrap-4.1.2/bootstrap.min.js"></script>
<script src="plugins/greensock/TweenMax.min.js"></script>
<script src="plugins/greensock/TimelineMax.min.js"></script>
<script src="plugins/scrollmagic/ScrollMagic.min.js"></script>
<script src="plugins/greensock/animation.gsap.min.js"></script>
<script src="plugins/greensock/ScrollToPlugin.min.js"></script>
<script src="plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
<script src="plugins/easing/easing.js"></script>
<script src="plugins/progressbar/progressbar.min.js"></script>
<script src="plugins/parallax-js-master/parallax.min.js"></script>
<script src="js/custom.js"></script>
</body>
</html>