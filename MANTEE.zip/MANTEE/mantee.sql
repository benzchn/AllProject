-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 29, 2019 at 09:37 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mantee`
--

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `pay_ID` int(11) NOT NULL,
  `order_ID` int(11) NOT NULL,
  `pay_date` date NOT NULL,
  `total_price` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `bank_name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `telephone` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `pay_time` varchar(20) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `producttype`
--

CREATE TABLE `producttype` (
  `protype_ID` int(4) NOT NULL,
  `protype_name` varchar(30) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `producttype`
--

INSERT INTO `producttype` (`protype_ID`, `protype_name`) VALUES
(1, 'shirt'),
(2, 'hat'),
(3, 'bag');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cart`
--

CREATE TABLE `tbl_cart` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `member_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_cart`
--

INSERT INTO `tbl_cart` (`id`, `product_id`, `quantity`, `member_id`) VALUES
(1, 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE `tbl_order` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `amount` double NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zip` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `payment_type` varchar(255) NOT NULL,
  `order_status` varchar(255) NOT NULL,
  `order_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_order`
--

INSERT INTO `tbl_order` (`id`, `customer_id`, `amount`, `name`, `address`, `city`, `state`, `zip`, `country`, `payment_type`, `order_status`, `order_at`) VALUES
(2, 1, 150, 'chanon chapirom', '528/209', 'maung', 'khonkaen', '40000', '???', 'PAYPAL', 'PENDING', '2019-04-29 21:12:44'),
(3, 1, 150, 'chanon chapirom', '528/209', 'maung', 'khonkaen', '40000', '???', 'PAYPAL', 'PENDING', '2019-04-29 21:14:02'),
(4, 1, 150, 'chanon chapirom', '528/209', 'maung', 'khonkaen', '40000', '???', 'PAYPAL', 'PENDING', '2019-04-29 21:15:27'),
(5, 1, 150, 'chanon chapirom', '528/209', 'maung', 'khonkaen', '40000', '???', 'PAYPAL', 'PENDING', '2019-04-29 21:15:51'),
(6, 1, 150, 'chanon chapirom', '528/209', 'maung', 'khonkaen', '40000', '???', 'PAYPAL', 'PENDING', '2019-04-29 21:17:14'),
(7, 1, 150, 'chanon chapirom', '528/209', 'maung', 'khonkaen', '40000', '???', 'PAYPAL', 'PENDING', '2019-04-29 21:18:36');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_item`
--

CREATE TABLE `tbl_order_item` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `item_price` double NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_order_item`
--

INSERT INTO `tbl_order_item` (`id`, `order_id`, `product_id`, `item_price`, `quantity`) VALUES
(2, 2, 3, 150, 1),
(3, 3, 3, 150, 1),
(4, 4, 3, 150, 1),
(5, 5, 3, 150, 1),
(6, 6, 3, 150, 1),
(7, 7, 3, 150, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_payment`
--

CREATE TABLE `tbl_payment` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `payment_status` varchar(255) NOT NULL,
  `payment_response` text NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE `tbl_product` (
  `id` int(10) NOT NULL,
  `name` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `details` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `code` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` double(10,2) NOT NULL,
  `type` int(10) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`id`, `name`, `details`, `code`, `image`, `price`, `type`, `quantity`) VALUES
(1, 'เสื้อคอเต่าแขนยาว', '• ลายทางวลับขาวดำ\r\n• สีขาว\r\n• น้ำหนักเบา\r\n• ผ้าฝ้าย 100%\r\n• อากาศถ่ายเทสะดวก\r\n• ไม่อุ้มน้ำ\r\n', '001', 'images/product_1.jpg', 140.00, 1, 5),
(2, 'เสื้อโค้ท', '• สีขาว \r\n• น้ำหนักเบา\r\n• หนังแกะ 100%\r\n• อบอุ่น', '002', 'images/product_2.jpg', 200.00, 1, 7),
(3, 'เสื้อเอวลอยแขนยาว', '• สีดำ\r\n• น้ำหนักเบา สบาย\r\n• ผ้าวาเลนติโน่ 100%\r\n• อากาศถ่ายเทสะดวก\r\n• ไม่อุ้มน้ำ', '003', 'images/product_3.jpg', 150.00, 1, 2),
(4, 'เสื้อและกางเกงขายาว', '• ลายทางแนวตั้ง\r\n• สีเหลืองอ่อน\r\n• น้ำหนักเบา สบาย\r\n• ผ้าลินิน 100%\r\n• อากาศถ่ายเทสะดวก\r\n• ไม่อุ้มน้ำ\r\n', '004', 'images/product_4.jpg', 160.00, 1, 3),
(5, 'เสื้อแขนสามส่วนคอวี', '• สีเขียวมรกต\r\n• น้ำหนักเบา สบาย\r\n• ผ้าฝ้าย 100%\r\n• อากาศถ่ายเทสะดวก\r\n• ไม่อุ้มน้ำ\r\n', '005', 'images/product_5.jpg', 150.00, 1, 9),
(6, 'เสื้อแจ๊กเก็ตยีนส์', '• สีน้ำเงินยีนส์\r\n• น้ำหนักเบา สบาย\r\n• ผ้าเดนิมจากอเมริกา 100%\r\n• อบอุ่น\r\n• ไม่อุ้มน้ำ\r\n', '006', 'images/product_6.jpg', 190.00, 1, 4),
(7, 'หมวกบักเก็ต', '• สีน้ำเงินยีนส์อ่อน\r\n• หนานุ่นด้วย ผ้าฝ้าย 100%\r\n• เย็นและเบาสบาย', '007', 'images/hat_1.jpg', 195.00, 2, 4),
(8, 'หมวกบักเก็ต', '• สีน้ำตาลอ่อน\r\n• กันแดด UPF 50+\r\n• หนานุ่นด้วย ผ้าฝ้าย 100%\r\n• เย็นและเบาสบาย', '008', 'images/hat_2.jpg', 120.00, 2, 5),
(9, 'หมวกฟีโดร่า', '• ฉลุลายลูกไม้\r\n• สีเนื้อ\r\n• ปีกหมวกใหญ่\r\n• หนานุ่นด้วย ผ้าฝ้าย 100%\r\n• เย็นและเบาสบาย\r\n', '009', 'images/hat_3.jpg', 125.00, 2, 6),
(10, 'หมวกฟล็อปปี้', '• มีลายดอกไม้\r\n• สีน้ำตาล\r\n• ทำจากกระดาษรีไซเคิล ', '010', 'images/hat_4.jpg', 120.00, 2, 7),
(11, 'หมวกฟีโดร่า', '• ฉลุลายลูกไม้\r\n• สีเนื้อ\r\n• กันแดด UPF 50+\r\n• ถักและทอด้วยมือ 100%\r\n• เย็นและเบาสบาย\r\n', '011', 'images/hat_5.jpg', 140.00, 2, 8),
(12, 'หมวกโคลช', '• สีเนื้อ\r\n• เบาสบาย และยืดหยุ่น \r\n• ปิดและบังแดดกระทบใบหน้าได้\r\n', '012', 'images/hat_6.jpg', 120.00, 2, 2),
(13, 'กระเป๋าหูหิ้วหนัง\r\nขนาดใหญ่', '• สีน้ำตาลเข้ม\r\n• วัสดุภายนอก:หนังวัว\r\n• รูปแบบ:หนังด้าน\r\n• รูปแบบการปิด:การกลัด\r\n• วัสดุภายใน:ผ้า\r\n\r\n\r\n', '013', 'images/bag_1.jpg', 250.00, 3, 9),
(14, 'กระเป๋าหูหิ้วหนัง\r\nขนาดกลาง', '• สีเงิน\r\n• วัสดุภายนอก:หนังเทียม\r\n• รูปแบบ:หนังเงา\r\n• รูปแบบการปิด:การกลัด\r\n• วัสดุภายใน:ผ้า', '014', 'images/bag_2.jpg', 400.00, 3, 3),
(15, 'กระเป๋าหูหิ้วหนัง\r\nขนาดกลาง', '• สีดำ\r\n• วัสดุภายนอก:หนังเทียม\r\n• รูปแบบ:หนังด้าน\r\n• รูปแบบการปิด:การกลัด\r\n• วัสดุภายใน:ผ้า\r\n', '015', 'images/bag_3.jpg', 250.00, 3, 11),
(16, 'กระเป๋าหูหิ้วหนัง\r\nขนาดใหญ่', '• สีทอง\r\n• วัสดุภายนอก:หนังอย่างดี\r\n• รูปแบบ:หนังเงา\r\n• รูปแบบการปิด:ซิป\r\n• วัสดุภายใน:โพลีเอสเตอร์', '016', 'images/bag_4.jpg', 300.00, 3, 10),
(17, 'กระเป๋าถือขนาดเล็ก', '• สีม่วงอมชมพู\r\n• วัสดุภายนอก:หนังวัว\r\n• รูปแบบ:หนังด้าน\r\n• รูปแบบการปิด:การกลัด\r\n• วัสดุภายใน:ผ้า\r\n\r\n', '017', 'images/bag_5.jpg', 250.00, 3, 15);

-- --------------------------------------------------------

--
-- Table structure for table `transfer`
--

CREATE TABLE `transfer` (
  `Bill_Number` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `prefix` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FName_User` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LName_User` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Email_User` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Amount_of_money_transferred` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bank` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Transaction_date` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Time_of_transaction` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `transfer`
--

INSERT INTO `transfer` (`Bill_Number`, `prefix`, `FName_User`, `LName_User`, `Email_User`, `Amount_of_money_transferred`, `bank`, `Transaction_date`, `Time_of_transaction`) VALUES
('', 'เลือก', '', '', '', '', 'เลือก', '', ''),
('1231', 'นาย', 'w', 's', 'asdaf@hotmail.com', '1005000.1200', 'ธนาคารกสิกรไทย', '26/08/1995', '25:00');

-- --------------------------------------------------------

--
-- Table structure for table `userdetail`
--

CREATE TABLE `userdetail` (
  `user_ID` int(4) NOT NULL,
  `user_fname` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `user_lname` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `user_add` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `user_email` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `user_tel` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(12) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(20) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `userdetail`
--

INSERT INTO `userdetail` (`user_ID`, `user_fname`, `user_lname`, `user_add`, `user_email`, `user_tel`, `username`, `password`) VALUES
(1, 'chanon', 'chapirom', '528/209', 'kingza_kongza@hotmail.com', '1298391273', 'gg', 'gg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`pay_ID`);

--
-- Indexes for table `producttype`
--
ALTER TABLE `producttype`
  ADD PRIMARY KEY (`protype_ID`);

--
-- Indexes for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_order_item`
--
ALTER TABLE `tbl_order_item`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_payment`
--
ALTER TABLE `tbl_payment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_product`
--
ALTER TABLE `tbl_product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transfer`
--
ALTER TABLE `transfer`
  ADD PRIMARY KEY (`Bill_Number`);

--
-- Indexes for table `userdetail`
--
ALTER TABLE `userdetail`
  ADD PRIMARY KEY (`user_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `pay_ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_order`
--
ALTER TABLE `tbl_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_order_item`
--
ALTER TABLE `tbl_order_item`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_payment`
--
ALTER TABLE `tbl_payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_product`
--
ALTER TABLE `tbl_product`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `userdetail`
--
ALTER TABLE `userdetail`
  MODIFY `user_ID` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
