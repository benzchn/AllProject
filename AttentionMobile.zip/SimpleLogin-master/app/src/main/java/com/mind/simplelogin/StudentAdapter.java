package com.mind.simplelogin;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

public class StudentAdapter extends RecyclerView.Adapter<StudentAdapter.ViewHolder> {

    private Context context;
    private List<Student> list;

    public StudentAdapter(Context context,List<Student> list){
        this.context = context;
        this.list = list;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.activity_admincheckgps, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        final Student student = list.get(position);

        holder.textName.setText("Name : " + student.getName_STD());
        holder.textId.setText("ID : " + student.getId_STD());
        holder.textTime.setText("Time : " + student.getTime());

        holder.parentLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String strUri = "http://maps.google.com/maps?q=loc:" + student.getLatitude() + "," + student.getLongtitude() + " (" + "Label which you want" + ")";
                Intent intent = new Intent(android.content.Intent.ACTION_VIEW, Uri.parse(strUri));
                intent.setClassName("com.google.android.apps.maps", "com.google.android.maps.MapsActivity");
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView textName, textId, textTime;
        public LinearLayout parentLayout;

        public ViewHolder(View itemView) {
            super(itemView);
            textTime = itemView.findViewById(R.id.time);
            textName = itemView.findViewById(R.id.Name);
            textId = itemView.findViewById(R.id.ID);
            parentLayout = itemView.findViewById(R.id.parent_layout);
        }
    }

}
