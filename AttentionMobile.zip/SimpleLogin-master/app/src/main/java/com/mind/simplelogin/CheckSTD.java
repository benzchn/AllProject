package com.mind.simplelogin;


import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;


public class CheckSTD extends AppCompatActivity implements View.OnClickListener,LocationListener {

    private static final int PERMISSIONS_REQUEST_READ_PHONE_STATE = 999;
    String deviceid;
    private TelephonyManager mTelephonyManager;
    EditText editTextStdName, editTextStdID;
    Button buttonAddPerson, buttonGetGPS;

    String latitude, longtitude;

    private final int GPS_REQUEST = 100;
    private LocationManager locationManager;


    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        editTextStdName = (EditText) findViewById(R.id.etUsername);
        editTextStdID = (EditText) findViewById(R.id.et_Std_ID);

        buttonAddPerson = (Button) findViewById(R.id.btCheck);
        buttonGetGPS = (Button) findViewById(R.id.btGETGPS);
        buttonAddPerson.setOnClickListener(this);
        buttonGetGPS.setOnClickListener(this);

            if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE)
                    != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.READ_PHONE_STATE}, PERMISSIONS_REQUEST_READ_PHONE_STATE);

            } else {
                getDeviceImei();
            }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case PERMISSIONS_REQUEST_READ_PHONE_STATE: {
                if (requestCode == PERMISSIONS_REQUEST_READ_PHONE_STATE && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    getDeviceImei();
                }
            }
            case GPS_REQUEST: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    getLocation();
                }
                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
            }
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private void getDeviceImei() {
        mTelephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    Activity#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for Activity#requestPermissions for more details.
            return;
        }
        deviceid = mTelephonyManager.getDeviceId();
        Log.d("msg", "DeviceImei " + deviceid);

    }
    //This is the part where data is transafeered from Your Android phone to Sheet by using HTTP Rest API calls

    private void   addPersonToSheet() {

        final ProgressDialog loading = ProgressDialog.show(this,"Adding","Please wait");
        final String name = editTextStdName.getText().toString().trim();
        final String stdID = editTextStdID.getText().toString().trim();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, "https://script.google.com/macros/s/AKfycbxNREZ5m0RKUdeeRmHO16bnd7G9XfWQDUba-icSl1QcDhzgbrw/exec",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        loading.dismiss();
                        Toast.makeText(CheckSTD.this,response,Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(getApplicationContext(), CheckSTD.class);
                        startActivity(intent);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> parmas = new HashMap<>();

                //here we pass params
                parmas.put("action","addPerson");
                parmas.put("StdName",name);
                parmas.put("StdID",stdID);
                parmas.put("imei",deviceid);
                parmas.put("lat",latitude);
                parmas.put("lng",longtitude);
                return parmas;
            }
        };
        int socketTimeOut = 50000;// u can change this .. here it is 50 seconds
        RetryPolicy retryPolicy = new DefaultRetryPolicy(socketTimeOut, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        stringRequest.setRetryPolicy(retryPolicy);
        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(stringRequest);
    }

    @Override
    public void onClick(View v) {
        if(v==buttonGetGPS){
            if (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.ACCESS_FINE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED
                    && ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.ACCESS_COARSE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED) {

                ActivityCompat.requestPermissions(CheckSTD.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION}, GPS_REQUEST);
            } else {
                getLocation();
                Log.d("msg", "Lat " + latitude);
                Log.d("msg", "long " + longtitude);
                if (latitude != null && longtitude != null)
                {
                    Toast.makeText(this, "Get GPS Finish!", Toast.LENGTH_LONG).show();
                }
            }
        }
        if(v==buttonAddPerson) {

            if (latitude == null && longtitude == null)
            {
                Toast.makeText(this, "Please get GPS !", Toast.LENGTH_LONG).show();
            }
            else {
                addPersonToSheet();
            }
        }
    }

    private void getLocation() {
        try {
            locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,
                    1000, 0, this);
        } catch (SecurityException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onLocationChanged(Location location) {
        latitude = String.valueOf(location.getLatitude());
        longtitude = String.valueOf(location.getLongitude());
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }
}
