package com.mind.simplelogin;

public class Student {

    public String Name_STD;
    public String Id_STD;
    public String latitude;
    public String longtitude;
    public String time;

    public void setTime(String time) {
        this.time = time;
    }

    public String getTime() {
        return time;
    }

    public Student() {
    }

    public Student(String name_STD, String id_STD, String latitude, String longtitude, String time) {
        this.Name_STD = name_STD;
        this.Id_STD = id_STD;
        this.latitude = latitude;
        this.longtitude = longtitude;
        this.time = time;
    }

    public void setName_STD(String name_STD) {
        Name_STD = name_STD;
    }

    public void setId_STD(String id_STD) {
        Id_STD = id_STD;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public void setLongtitude(String longtitude) {
        this.longtitude = longtitude;
    }

    public String getName_STD() {
        return Name_STD;
    }

    public String getId_STD() {
        return Id_STD;
    }

    public String getLatitude() {
        return latitude;
    }

    public String getLongtitude() {
        return longtitude;
    }
}
