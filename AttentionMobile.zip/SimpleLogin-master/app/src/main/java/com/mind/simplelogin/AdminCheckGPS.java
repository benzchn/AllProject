package com.mind.simplelogin;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class AdminCheckGPS extends AppCompatActivity {

    private RequestQueue mQueue;

    Student student;
    private RecyclerView mList;
    RequestQueue requestQueue;
    private LinearLayoutManager linearLayoutManager;
    private DividerItemDecoration dividerItemDecoration;
    private List<Student> studentList;
    private RecyclerView.Adapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_list);

        mList = findViewById(R.id.main_list);

        studentList = new ArrayList<>();
        adapter = new StudentAdapter(getApplicationContext(),studentList);

        linearLayoutManager = new LinearLayoutManager(this);

        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);

        dividerItemDecoration = new DividerItemDecoration(mList.getContext(), linearLayoutManager.getOrientation());

        mList.setHasFixedSize(true);
        mList.setLayoutManager(linearLayoutManager);
        mList.addItemDecoration(dividerItemDecoration);
        mList.setAdapter(adapter);
        mQueue = Volley.newRequestQueue(this);

        FloatingActionButton buttonParse = findViewById(R.id.button_parse);

        jsonParse();


        buttonParse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AdminCheckGPS.this, AdminCheckGPS.class);
                startActivity(intent);
            }
        });

    }

    private void jsonParse() {

        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading...");
        progressDialog.show();

        String url = "https://script.google.com/macros/s/AKfycbxg62__jyN_0mSA60oOdROrJuYvBs7H3d-mcqa5FeBnysggPA4l/exec";


        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(url, new Response.Listener<JSONArray>() {

                    @Override

                        public void onResponse(JSONArray response) {
                            for (int i = 0; i < response.length(); i++) {
                                try {
                                    JSONObject jsonObject = response.getJSONObject(i);

                                    student = new Student();

                                student.setTime(jsonObject.getString("time"));
                                student.setName_STD(jsonObject.getString("std_name"));
                                student.setId_STD(jsonObject.getString("std_id"));
                                student.setLatitude(jsonObject.getString("latitude"));
                                student.setLongtitude(jsonObject.getString("longtitude"));

                                studentList.add(student);

                                } catch (JSONException e) {
                                    e.printStackTrace();
                                    progressDialog.dismiss();
                                }
                            }
                        adapter.notifyDataSetChanged();
                        progressDialog.dismiss();
                    }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("Volley", error.toString());
                progressDialog.dismiss();
            }
        });
        requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(jsonArrayRequest);
    }
}