package com.example.foodcal;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

public class Register extends Activity implements  View.OnClickListener   {
    DatabaseHelp myDb;
    EditText editName,editAge ,editWeight, editHeight;
    RadioGroup editSex;
    RadioButton radioSexButton;
    Button btnAddData;
    Spinner spinner;
    String event;
    spinnerAdapter adapter;
    String[] spinnerValue = {
            "ไม่เคยออกกำลังกาย",
            "ออกกำลังกายอาทิตย์ 1-3 วัน",
            "ออกกำลังกายอาทิตย์ 3-5 วัน",
            "ออกกำลังกายอาทิตย์ 6-7 วัน",
            "ออกกำลังกายทุกวันเช้า - เย็น",
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        editName = (EditText)findViewById(R.id.Text_showbmi);
        editSex = (RadioGroup) findViewById(R.id.radioSex);
        editAge = (EditText)findViewById(R.id.text_showMes);
        editWeight = (EditText)findViewById(R.id.text_showcal);
        editHeight = (EditText)findViewById(R.id.input_height);
        btnAddData = (Button)findViewById(R.id.btn_goMenu);

        btnAddData.setOnClickListener(this);


        spinner =(Spinner)findViewById(R.id.spinner1);

        adapter = new spinnerAdapter(Register.this, android.R.layout.simple_list_item_1);
        adapter.addAll(spinnerValue);
        adapter.add("เลือกกิจกรรม");
        spinner.setAdapter(adapter);
        spinner.setSelection(adapter.getCount());

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {
                // TODO Auto-generated method stub

                if(spinner.getSelectedItem() == "เลือกกิจกรรม")
                {

                    //Do nothing.
                }
                else{

                   // Toast.makeText(Register.this, spinner.getSelectedItem().toString(), Toast.LENGTH_LONG).show();
                    event = spinner.getSelectedItem().toString();
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // TODO Auto-generated method stub

            }
        });

    }

    @Override
    public void onClick(View v) {
        int selectedId = editSex.getCheckedRadioButtonId();
        radioSexButton = (RadioButton) findViewById(selectedId);
        String name = editName.getText().toString();
        String sex = radioSexButton.getText().toString();
        String age = editAge.getText().toString();
        String weight = editWeight.getText().toString();
        String height = editHeight.getText().toString();


        final DatabaseHelp myDB = new DatabaseHelp(this);
        long flag = myDB.insertData(name,sex,age,weight,height,event);
        if(flag>0){
            Toast.makeText(getApplicationContext(),"insert sucsess",Toast.LENGTH_LONG).show();
            Intent intent = new Intent(Register.this, Showbmr.class);
            startActivity(intent);
            finish();
        }else{
            Toast.makeText(getApplicationContext(),"insert fail",Toast.LENGTH_LONG).show();
        }

    }
}


