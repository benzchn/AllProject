package com.example.foodcal;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

public class DatabaseHelp extends SQLiteOpenHelper {
    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "register";
    public static final String TABLE_NAME = "register_table";


    public DatabaseHelp(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_NAME + "(Name TEXT(20)," + " Sex TEXT(10)," +
                " Age TEXT(10),"+ " Weight TEXT(10)," + "Height TEXT(10)," + "Event TEXT(50));");
        Log.d("Create Table","Sucsessfully");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
        onCreate(db);
    }

    public long insertData(String name,String sex,String age,String weight,String height,String event) {
        try {
            SQLiteDatabase db;
            db = this.getWritableDatabase();
            ContentValues val = new ContentValues();
            val.put("Name",name);
            val.put("Sex",sex);
            val.put("Age",age);
            val.put("Weight",weight);
            val.put("Height",height);
            val.put("Event",event);
            long rows = db.insert(TABLE_NAME,null,val);
            db.close();
            return rows;
        }catch (Exception e){
            return -1;
        }
    }

//    public ArrayList<HashMap<String, String>> SelectAllData(){
//    try{
//        ArrayList<HashMap<String,String>> MyArrlist = new ArrayList<HashMap<String, String>>();
//        HashMap<String,String> map;
//        SQLiteDatabase db;
//        db = this.getReadableDatabase();
//        String strSQL = "SELECT * FROM " + TABLE_NAME;
//        Cursor cursor = db.rawQuery(strSQL,null);
//
//        if(cursor != null){
//            if (cursor.moveToFirst()){
//                do {
//                    map = new HashMap<String, String>();
//                    map.put("Name",cursor.getString(0));
//                    map.put("Sex",cursor.getString(1));
//                    map.put("Age",cursor.getString(2));
//                    map.put("Weight",cursor.getString(3));
//                    map.put("Height",cursor.getString(4));
//                    MyArrlist.add(map);
//                }while (cursor.moveToNext());
//            }
//        }
//        cursor.close();
//        db.close();
//        return MyArrlist;
//    }catch (Exception e){
//        return null;
//    }
//    }

    public Cursor allData(){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME,null);
        return cursor;
    }

    public Cursor getWH(){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT Weight,Height FROM " + TABLE_NAME,null);
        return cursor;
    }

}
