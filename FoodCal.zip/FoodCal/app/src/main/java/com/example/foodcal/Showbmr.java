package com.example.foodcal;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Showbmr extends Activity implements View.OnClickListener {
    Button btngoMenu;
    DatabaseHelp db;
    String w,h,a,s,r,bmi_valueSTR;
    EditText showbmi,showrate,showcal;
    double weight,height,height1,bmi_value,age,BMR,rate,Cal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_showbmr);
        db = new DatabaseHelp(this);
        Cursor cursor = db.allData();
        if (cursor.getCount() == 0) {
            Toast.makeText(getApplicationContext(), "No DATA", Toast.LENGTH_SHORT).show();
        } else {
            while (cursor.moveToNext()) {
                s = ""+cursor.getString(1);
                a = ""+cursor.getString(2);
                w = ""+cursor.getString(3);
                h = ""+cursor.getString(4);
                r = ""+cursor.getString(5);
            }

            // คำนวณ BMI
             weight = Double.parseDouble(w);
             height = Double.parseDouble(h);
             height1 = height/100;
             bmi_value = weight/(height1*height1);
             bmi_valueSTR = String.format("%1.4f",bmi_value);
            showbmi = (EditText)findViewById(R.id.Text_showbmi);
            showbmi.setText(bmi_valueSTR);

            // วิเคราะห์ น้ำหนักตัว
            showrate = (EditText)findViewById(R.id.text_showMes);
            if (bmi_value>30){
                showrate.setText("โรคอ้วนอันตราย");
            }else if (bmi_value>25){
                showrate.setText("โรคอ้วน");
            }else if (bmi_value>23){
                showrate.setText("น้ำหนักเกิน");
            }else if (bmi_value>18.5){
                showrate.setText("สมส่วน");
            }else {
                showrate.setText("น้ำหนักต่ำกว่าเกณฑ์");
            }

            //คำนวณ CAL
            age = Integer.parseInt(a);
            showcal = (EditText)findViewById(R.id.text_showcal);

            if(r.equals("ไม่เคยออกกำลังกาย")){
                rate = 1.2;
            }else if (r.equals("ออกกำลังกายอาทิตย์ 1-3 วัน")){
                rate = 1.375;
            }else if (r.equals("ออกกำลังกายอาทิตย์ 3-5 วัน")){
                rate = 1.55;
            }else if (r.equals("ออกกำลังกายอาทิตย์ 6-7 วัน")){
                rate = 1.725;
            }else if (r.equals("ออกกำลังกายทุกวันเช้า - เย็น")){
                rate = 1.9;
            }

            if(s.equals("ชาย")){
                BMR = 66+(13.7*weight)+(5*height)-(6.8*age);
                Cal = BMR * rate;
                int Cal1 = (int) Cal;
                String Cal2 = String.format("%d kcal ต่อวัน",Cal1);
                showcal.setText(Cal2);
            }else {
                BMR = 665+(9.6*weight)+(1.8*height)-(4.7*age);
                Cal = BMR * rate;
                int Cal1 = (int) Cal;
                String Cal2 = String.format("%d kcal ต่อวัน",Cal1);
                showcal.setText(Cal2);
            }
        }

init();
        btngoMenu.setOnClickListener(this);
    }

    private void init() {
        btngoMenu = (Button) findViewById(R.id.btn_goMenu);
    }

    @Override
    public void onClick(View v) {

        Intent intent = new Intent(Showbmr.this, MenuBar.class);
        startActivity(intent);
        finish();
    }
}
