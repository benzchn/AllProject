/**
 *
 */
function Game2 () {
	Phaser.State.call(this);
}

/** @type Phaser.State */
var proto = Object.create(Phaser.State);
Game2.prototype = proto;

Game2.prototype.create = function() {
	this.bg = this.game.add.sprite(0, 0, "bg4");
	this.bg.fixedToCamera = true;
	this.bg = this.game.add.sprite(0, -120, "BB");
	this.bg.fixedToCamera = true;
	this.bg = this.game.add.sprite(0, -120, "BBB");
	this.bg.fixedToCamera = true;
};