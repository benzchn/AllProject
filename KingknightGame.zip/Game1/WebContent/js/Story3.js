/**
 *
 */
function Story3 () {
	Phaser.State.call(this);
}

/** @type Phaser.State */
var proto = Object.create(Phaser.State);
Story3.prototype = proto;


Story3.prototype.create = function() {
	this.bg = this.game.add.sprite(0, 0, "story3");
	
	this.bg.inputEnabled = true;
	this.bg.events.onInputDown.add(this.startGame, this);
	
};

Story3.prototype.startGame = function() {
	this.game.state.start("Howtoplay");
};