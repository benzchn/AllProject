/**
 * Level state.
 */
function Story() {
	Phaser.State.call(this);
}

/** @type Phaser.State */
var proto = Object.create(Phaser.State);
Story.prototype = proto;

Story.prototype.create = function() {
	this.bg = this.game.add.sprite(0, 0, "story1");
	
	this.next = this.add.sprite(this.world.centerX + 50, this.world.centerY + 150, "next1");
	this.next.inputEnabled = true;
	this.next.events.onInputDown.add(this.startGame, this);
};

Story.prototype.startGame = function() {
	this.game.state.start("Story2");
};