/**
 * Menu state.
 */
function Menu() {
	Phaser.State.call(this);
}

/** @type Phaser.State */
var proto = Object.create(Phaser.State);
Menu.prototype = proto;

Menu.prototype.preload = function() {
	this.load.pack("start", "assets/assets-pack.json");
};

Menu.prototype.create = function() {

	this.bg = this.game.add.sprite(0, 0, "bg");
	this.bg.fixedToCamera = true;
	this.bg.height = this.game.height;

	var style = {
		font : "bold 20px Arial",
		fill : "#fff",
		boundsAlignH : "center",
		boundsAlignV : "middle"
	};
	this.text = this.game.add.text(this.world.centerX - 40,
			this.world.centerY + 510, "-GGEZ-", style);
	this.text.setShadow(3, 3, 'rgba(0,0,0,0.5)', 2);

	// logo
	this.addlg = this.addLogo();
	// credit
	this.credit = this.addCredit();
	this.credit.inputEnabled = true;
	this.credit.events.onInputDown.add(this.startCredit, this);

	this.addK = this.addKnight();

	this.addST = this.addStart();
	this.addST.play("start");
	this.addST.inputEnabled = true;
	this.addST.events.onInputDown.add(this.goclick, this);
};

Menu.prototype.goclick = function() {

	this.addK.play("walk");
	var twn = this.add.tween(this.addK);
	twn.to({
		x : 1000
	}, 3000, "Quad.easeInOut", true, 0, 0, false);
	this.game.time.events.add(Phaser.Timer.SECOND * 3, this.startStory, this);
	
};

function gframes(key, n) {
	var f = [];
	for (var i = 1; i <= n; i++) {
		var kf = key + "_" + (("" + i).slice(-3));
		f.push(kf);
	}
	return f;
}
function Dframes(key, n) {
	var f = [];
	for (var i = 1; i <= n; i++) {
		var kf = key + "_" + (("00" + i).slice(-3));
		f.push(kf);
	}
	return f;
}
Menu.prototype.addLogo = function() {
	var m = this.add.sprite(this.world.centerX, this.world.centerY - 300,
			"logo");
	m.scale.set(0.9);
	m.anchor.set(0.5, 0.5);
	return m;
};

Menu.prototype.addCredit = function() {
	var m = this.add.sprite(this.world.centerX + 50, this.world.centerY + 328,
			"credit");
	m.scale.set(0.4);
	m.anchor.set(0.5, 0.5);
	return m;
};

Menu.prototype.addStart = function() {
	var m = this.add.sprite(this.world.centerX, this.world.centerY, "startAdd");
	m.animations.add("start", gframes("Start", 2), 2, true);
	m.anchor.set(0.5, 0.5);
	this.game.physics.enable(m);
	m.body.collideWorldBounds = true;
	return m;
};

Menu.prototype.addKnight = function() {
	var m = this.add.sprite(this.world.centerX - 220, this.world.centerY + 350,
			"Knight");
	m.animations.add("idle", Dframes("idel", 10), 10, true);
	m.animations.add("walk", Dframes("walk", 10), 10, true);
	m.scale.set(0.9);
	m.anchor.set(0.5, 0.5);
	m.play("idle");
	this.game.physics.enable(m);
	m.body.collideWorldBounds = true;
	return m;
};
Menu.prototype.startStory = function() {
	this.game.state.start("Story");
};

Menu.prototype.startCredit = function() {
	this.game.state.start("Credit");
};