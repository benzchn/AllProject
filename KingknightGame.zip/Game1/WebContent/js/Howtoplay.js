/**
 *
 */
function Howtoplay () {
	Phaser.State.call(this);
}

var proto = Object.create(Phaser.State);
Howtoplay.prototype = proto;

Howtoplay.prototype.create = function() {
	this.bg = this.game.add.sprite(0, 0, "Howtoplay");
	this.bg.inputEnabled = true;
	this.bg.events.onInputDown.add(this.startGame, this);
	
};

Howtoplay.prototype.startGame = function() {
	this.game.state.start("Game1");
};