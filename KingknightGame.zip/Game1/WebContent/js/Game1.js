/**
 * 
 */
function Game1() {
	Phaser.State.call(this);
}

/** @type Phaser.State */
var proto = Object.create(Phaser.State);
Game1.prototype = proto;

Game1.prototype.preload = function() {
	this.game.load.image('attack', 'assets/Howtoplay/attack.png');
	this.game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
	this.game.scale.fullScreenScaleMode = Phaser.ScaleManager.EXACT_FIT;
};

var text;
var bullets;
var speed = 30;
var score = 0;
var scoreString = '';
var scoreText;
var fireButton;
var bulletTime = 0;

Game1.prototype.create = function() {
	
	this.game.physics.startSystem(Phaser.Physics.ARCADE);
	this.game.physics.arcade.gravity.y = 1000;
	if (!this.game.device.desktop) {
		this.game.input.onDown.add(gofull, this);
	}
	this.nums = {
		score : 0,
		heal : 0,
		damage : 0
	};

	//sounds
	this.sounds = [];
	this.music = this.game.add.audio('soundtheme', 0.5, true);
	this.music.play();
	this.sounds['zdead1'] = this.add.audio("zdead1", 1, false);
	this.sounds['zombie_1'] = this.add.audio("zombie_1", 1, false);
	this.sounds['zombie_2'] = this.add.audio("zombie_2", 1, false);
	this.sounds['sword'] = this.add.audio("sword", 1, false);
	this.sounds['hurt'] = this.add.audio("hurt", 1, false);
	for (i in this.sounds) {
		this.sounds[i].allowMultiple = true;
	}
	
	// BG
	this.bg = this.game.add.sprite(0, 0, "bg4");
	this.bg.fixedToCamera = true;
	this.bg = this.game.add.sprite(0, -120, "BB");
	this.bg.fixedToCamera = true;
	this.bg = this.game.add.sprite(0, -120, "BBB");
	this.bg.fixedToCamera = true;

	
	// Text
//	text = this.game.add.text(this.game.world.centerX, this.game.world.centerY,
//			"Tap To Start", {
//				font : "65px Arial",
//				fill : "#ff0044",
//				align : "center"
//			});
//	text.anchor.setTo(0.5, 0.5);
//	this.game.input.onDown.addOnce(this.removeText, this);

	// map
	this.map = this.game.add.tilemap("map1");
	this.map.addTilesetImage("tile_set");
	this.map_Tile1 = this.map.createLayer("Tile Layer 2");
	this.map_Tile = this.map.createLayer("Tile Layer 1");
	this.map_Tile.resizeWorld();
	this.map.setCollisionBetween(0, 17, true, this.map_Tile);

	// creat player & enemy
	this.enemies = this.add.group();
	this.flagfinish = this.add.group();
	
	for (x in this.map.objects.object) {
		var obj = this.map.objects.object[x];
		if (obj.type == "player") {
			this.player = this.addPlayer(obj.x, obj.y);
			this.game.camera.follow(this.player, null, 0.1, 0.1);
			this.player.maxHealth = 3;
			this.player.setHealth(3);
			this.player.canhit = true;
		} else if (obj.type == "enemy1") {
			this.goblin = this.addGoblin(obj.x, obj.y + 20);
			this.enemies.add(this.goblin);
		} else if (obj.type == "enemy2") {
			this.greenhorn = this.addGreenhorn(obj.x, obj.y + 20);
			this.enemies.add(this.greenhorn);
		} else if (obj.type == "enemy3") {
			this.WhiteBird = this.addWhiteBird(obj.x, obj.y + 20);
			this.enemies.add(this.WhiteBird);
		} else if (obj.type == "enemy5") {
			this.goblin = this.addGoblin(obj.x, obj.y + 20);
			this.enemies.add(this.goblin);
		}else if (obj.type == "enemy8") {
			this.greenhorn = this.addGreenhorn(obj.x, obj.y + 20);
			this.enemies.add(this.greenhorn);
		}else if (obj.type == "enemy9") {
			this.WhiteBird = this.addWhiteBird(obj.x, obj.y + 20);
			this.enemies.add(this.WhiteBird);
		}else if (obj.type == "enemy11") {
			this.goblin = this.addGoblin(obj.x, obj.y + 20);
			this.enemies.add(this.goblin);
		}else if (obj.type == "enemy14") {
			this.greenhorn = this.addGreenhorn(obj.x, obj.y + 20);
			this.enemies.add(this.greenhorn);
		}else if (obj.type == "enemy16") {
			this.WhiteBird = this.addWhiteBird(obj.x, obj.y + 20);
			this.enemies.add(this.WhiteBird);
		}else if (obj.type == "enemy20") {
			this.greenhorn = this.addGreenhorn(obj.x, obj.y + 20);
			this.enemies.add(this.greenhorn);
		}else if (obj.type == "enemy25") {
			this.goblin = this.addGoblin(obj.x, obj.y + 20);
			this.enemies.add(this.goblin);
		}else if (obj.type == "enemy28") {
			this.WhiteBird = this.addWhiteBird(obj.x, obj.y + 20);
			this.enemies.add(this.WhiteBird);
		}else if (obj.type == "enemy30") {
			this.goblin = this.addGoblin(obj.x, obj.y + 20);
			this.enemies.add(this.goblin);
		}else if (obj.type == "enemy32") {
			this.flagg = this.addflag(obj.x, obj.y + 20);
			this.flagfinish.add(this.flagg);
		}
	}
	
	this.heart1 = this.game.add.sprite(500,100,"heart");
	this.heart1.anchor.setTo(0.5, 0.5);
	this.heart1.scale.set(0.1);
	this.heart1.fixedToCamera = true;
	this.heart2 = this.game.add.sprite(600,100,"heart");
	this.heart2.anchor.setTo(0.5, 0.5);
	this.heart2.scale.set(0.1);
	this.heart2.fixedToCamera = true;
	this.heart3 = this.game.add.sprite(700,100,"heart");
	this.heart3.anchor.setTo(0.5, 0.5);
	this.heart3.scale.set(0.1);
	this.heart3.fixedToCamera = true;
	
	
	
	bullets = this.game.add.group();
    bullets.enableBody = true;
    bullets.physicsBodyType = Phaser.Physics.ARCADE;
    bullets.createMultiple(2, 'Sword');
    bullets.setAll('anchor.x', 0.5);
    bullets.setAll('anchor.y', 1);
    bullets.setAll('outOfBoundsKill', true);
    bullets.setAll('checkWorldBounds', true);
	
//  The score
    scoreString = 'Score : ';
    scoreText = this.game.add.text(30, 70, scoreString + score, { font: '60px Arial', fill: '#fff' });
    scoreText.fixedToCamera = true;
    
    fireButton = this.game.input.keyboard.addKey(Phaser.Keyboard.SPACEBAR);
};


Game1.prototype.update = function() {

	this.game.physics.arcade.collide(this.player, this.map_Tile);
	this.game.physics.arcade.collide(this.enemies, this.map_Tile);
	this.game.physics.arcade.collide(this.flagg, this.map_Tile);
	this.game.physics.arcade.collide(this.player, this.enemies,this.onPlayerCollide, null, this);
	
	this.game.physics.arcade.collide(this.player, this.flagfinish,this.finish, null, this);
	
	if (this.game.input.keyboard.isDown(Phaser.Keyboard.LEFT))
    {
		this.player.play("walk");
        this.player.x -= speed;
    }
    else if (this.game.input.keyboard.isDown(Phaser.Keyboard.RIGHT))
    {
    	this.player.play("walk");
        this.player.x += speed;
    } 
    else if (this.game.input.keyboard.isDown(Phaser.Keyboard.SPACEBAR))
    {
        this.player.play("attack");
    }
    else
    {
        this.player.rotation = 0;
    }
	if (fireButton.isDown)
    {
        this.fireBullet();
    }
	this.game.physics.arcade.overlap(bullets, this.enemies, this.collisionHandler, null, this);
};

Game1.prototype.addPlayer = function(x, y) {
	this.m = this.add.sprite(x, y, "AmazonStyle");
	this.m.animations.add("walk", Dframes("walk", 10), 5, true);
	this.m.animations.add("attack", Dframes("attack", 15), 30, false);
	this.m.animations.add("defend", Dframes("Defend", 10), 10, false);
	this.m.animations.add("dead", Dframes("dead", 10), 10, false);
	this.m.anchor.set(0.5, 0.5);
	this.m.play("walk");
	this.game.physics.enable(this.m);
	this.m.body.collideWorldBounds = true;
	return this.m;

};

Game1.prototype.addflag = function(x, y) {
	this.m = this.add.sprite(x, y, "flag");
	this.game.physics.enable(this.m);
	this.m.body.collideWorldBounds = true;
	return this.m;
};

function Eframe(key, n) {
	var f = [];
	for (var i = 0; i <= n; i++) {
		var kf = key + "_" + (("00" + i).slice(-3));
		f.push(kf);
	}
	return f;
}

Game1.prototype.addGoblin = function(x, y) {
	g = this.add.sprite(x, y, "Goblin");
	g.animations.add("dead", Eframe("0_Goblin_Dying", 14), 14, false);
	g.animations.add("idle", Eframe("0_Goblin_Idle Blinking", 18), 20, true);
	g.play("idle");
	this.sounds["zombie_1"].play();
	g.scale.set(0.3);
	g.scale.x *= -1;
	g.anchor.set(0.5, 0.5);
	this.game.physics.enable(g);
	g.body.collideWorldBounds = true;
	return g;
};

Game1.prototype.addGreenhorn = function(x, y) {
	c = this.add.sprite(x, y, "enemy");
	c.animations.add("hit", Eframe("greenhornhit", 2), 2, true);
	c.animations.add("idle", Eframe("greenhornidle", 2), 2, true);
	c.play("idle");
	this.sounds["zombie_2"].play();
	c.scale.set(0.5);
	c.anchor.set(0.5, 0.5);
	this.game.physics.enable(c);
	c.body.collideWorldBounds = true;
	return c;
};

Game1.prototype.addWhiteBird = function(x, y) {
	c = this.add.sprite(x, y, "enemy");
	c.animations.add("idle", Eframe("whitebirdidle", 4), 4, true);
	c.animations.add("hit", Eframe("whitebirdhit", 2), 2, true);
	c.play("idle");
	this.sounds["zombie_1"].play();
	c.scale.set(0.5);
	c.scale.x *= -1;
	c.anchor.set(0.5, 0.5);
	this.game.physics.enable(c);
	c.body.collideWorldBounds = true;
	return c;
};

function Dframes(key, n) {
	var f = [];
	for (var i = 1; i <= n; i++) {
		var kf = key + "_" + (("00" + i).slice(-3));
		f.push(kf);
	}
	return f;
}

Game1.prototype.removeText = function() {
	text.destroy();
};

Game1.prototype.gofull = function() {
	game.scale.startFullScreen(false);
};
var n = 0;

Game1.prototype.onPlayerCollide = function(player, alien) {
	n += 1;
	player.damage(1);
	alien.kill();
	this.sounds["hurt"].play();
	player.canhit = false;
	player.alpha = 0.1;
	var tw = this.add.tween(player);
	tw.to({
		alpha : 1
	}, 200, "Linear", true, 0, 5);
	tw.onComplete.addOnce(function() {
		this.alpha = 1;
		this.canhit = true;
	}, player);
	if (n==1){this.heart1.destroy();}
	else if (n==2){this.heart2.destroy();}
	else if (n==3){this.player.play("dead"); this.heart3.destroy();}
	if(n==3){
	var sprite = this.add.sprite(400,350, "gameover");
	sprite.anchor.set(0.5, 0.5);
	sprite.fixedToCamera = true;
	sprite.inputEnabled = true;
	n=0;
	sprite.events.onInputDown.add(this.end, this);
	}
	return true;
};

Game1.prototype.collisionHandler = function(bullet, alien) {
	alien.kill();
	bullet.kill();
//  Increase the score
    score += 20;
    scoreText.text = scoreString + score;
    this.sounds["zdead1"].play();
};

Game1.prototype.fireBullet = function() {

    //  To avoid them being allowed to fire too fast we set a time limit
    if (this.game.time.now > bulletTime)
    {
        //  Grab the first bullet we can from the pool
        bullet = bullets.getFirstExists(false);

        if (bullet)
        {
            //  And fire it
            bullet.reset(this.player.x, this.player.y + 8);
            bullet.body.velocity.x = 1000;
            bulletTime = this.game.time.now + 300;
            bullet.angle += 1;
            this.sounds["sword"].play();
        }
    }
};

Game1.prototype.finish = function() {
	
	this.win = this.game.add.sprite(400,350,"you-win-png-1");
	this.win.anchor.setTo(0.5, 0.5);
	//this.win.scale.set(1);
	
    this.win.fixedToCamera = true;
    //this.game.state.restart();
    //this.win.inputEnabled = true;
    //this.win.events.onInputDown.add(this.end, this);
    //this.game.time.events.add(Phaser.Timer.SECOND * 3, this.startStory, this);
};

Game1.prototype.end = function() {
	score = 0;
	this.game.state.restart();
	
};
