/**
 *
 */
function Credit () {
	Phaser.State.call(this);
}

/** @type Phaser.State */
var proto = Object.create(Phaser.State);
Credit.prototype = proto;

Credit.prototype.preload = function() {
	this.load.image("background", "assets/images/70.png");
	this.game.load.audio('Endcredit', 'assets/sound/EndcreditGame.ogg');
};

var credit;
Credit.prototype.create = function() {
	this.addBg();
	credit = this.game.add.audio('Endcredit',1,false,true);
	credit.play();
	
};

Credit.prototype.addBg = function() {
	
	this.bg = this.game.add.sprite(0, 0, "credit1");
	
	this.input.onDown.add(this.startGame, this);
};

Credit.prototype.startGame = function() {
	this.game.state.start("Menu");
};
