/**
 *
 */
function Story2 () {
	Phaser.State.call(this);
}

/** @type Phaser.State */
var proto = Object.create(Phaser.State);
Story2.prototype = proto;

Story2.prototype.create = function() {
	this.bg = this.game.add.sprite(0, 0, "story2");
	
	this.next2 = this.add.sprite(this.world.centerX + 100, this.world.centerY-50, "next2");
	this.next2.scale.set(0.4);
	this.next2.inputEnabled = true;
	this.next2.events.onInputDown.add(this.startGame, this);
};

Story2.prototype.startGame = function() {
	this.game.state.start("Story3");
};